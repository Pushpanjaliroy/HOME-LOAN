package com.lti.core.service;

import java.util.List;

import com.lti.core.exceptions.AdminException;
import com.lti.core.dao.AdminDao;
import com.lti.core.entities.AdminEntity;

public interface AdminService {
	public List<AdminEntity> showAllAdmin() throws AdminException;
	public AdminEntity showAdminOnId(int userId) throws AdminException;
	/*
	 * public int createNewEmployee(Employee emp) throws EmpException;
	 */
}
