package com.lti.core.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

/*import com.lti.core.exception.EmpException;*/
import com.lti.core.dao.AdminDao;
import com.lti.core.entities.AdminEntity;

@Service("AdminService")
//@Lazy(true)
public class AdminServiceImpl implements AdminService{	
	
	public AdminServiceImpl() {
		System.out.println("ServiceLayer Class");
	}
	
	@Resource(name="AdminDao")
	private AdminDao dao; //creating reference of dao layer in the service layer class
	
	@Override
	public List<AdminEntity> showAllAdmin() throws AdminException {
		
		return dao.getAllAdminEntity();
	}

	
	  @Override public AdminEntity showAdminOnId(int empId) throws AdminException {
	  
	  return dao.getAdminOnId(userId); }
	  
	/*
	 * @Override public int createNewEmployee(Employee emp) throws EmpException {
	 * 
	 * return dao.insertNewEmployee(emp); }
	 */

	
}
