package com.lti.core.dao;

import java.sql.SQLException;
import java.util.List;

import com.lti.core.exceptions.AdminException;

import com.lti.core.entities.AdminEntity;


public interface AdminDao {
	public List<AdminEntity> getAllEmps() throws AdminException ;	
	public AdminEntity getAdminEntityOnId(int empId) throws AdminException; 
	 //public int	 insertNewEmployee(Employee emp) throws EmpException;
	 
	/*
	 * public Employee getStudentOnId(int stId) throws StudException; public int
	 * insertNewStud(Student st) throws StudException;
	 */
	

}
