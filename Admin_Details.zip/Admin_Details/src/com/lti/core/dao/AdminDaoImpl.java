package com.lti.core.dao;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.lti.core.exceptions.AdminException;
import com.lti.core.entities.AdminEntity;
@Repository("AdminDao")
@Scope("singleton")
//@Lazy(true)
public class AdminDaoImpl implements AdminDao{
	
	@PersistenceContext
	private EntityManager manager;
	

	//View all data using JDBC template
	/*@Override
	public List<AdminEntity> getAllAdmin() throws AdminException {
		
		 
		Query qry= manager.createQuery("from Admin");
		List<AdminEntity> employeeList = qry.getResultList();
		return adminList;
		*/
		
		/*
		 * String
		 * qry1="SELECT employee_id, first_name, last_name, email, hire_date, job_id FROM employees"
		 * ; employeeList =jTemp.query(qry1,new RowMapperFactory());
		 */
		
				

	
	  //view data for specified id
	  
	  @Override 
	  public AdminEntity getAdminOnId(int empId) throws AdminException {
	  AdminEntity admin = manager.find(AdminEntity.class, userId);
	  
	  return admin;
	  
	  }
	  
	/*
	 * //inserting values into table
	 * 
	 * @Override public int insertNewEmployee(Employee emp) throws EmpException {
	 * 
	 * String qry3 =
	 * "INSERT INTO employees(employee_id, first_name, last_name, email, hire_date, job_id) VALUES(?,?,?,?,?,?)"
	 * ; Object[] params = {emp.getEmpId(),emp.getFirstName(),
	 * emp.getLastName(),emp.getMailId(), emp.getHireDate(),emp.getJobId()}; int
	 * returnVal = jTemp.update(qry3,params);
	 * 
	 * return returnVal; }
	 */
	 
	/*
	 * class RowMapperFactory implements RowMapper<Employee>{ //to retrieve all the
	 * records from the table
	 * 
	 * @Override public Employee mapRow(ResultSet rs, int rowNum) throws
	 * SQLException { int empId = rs.getInt("employee_id"); String firstName =
	 * rs.getString("first_name"); String lastName = rs.getString("last_name");
	 * String mailId = rs.getString("email"); Date hireDate =
	 * rs.getDate("hire_date"); String jobId = rs.getString("job_id");
	 * 
	 * Employee emp1 = new Employee(); emp1.setEmpId(empId);
	 * emp1.setFirstName(firstName); emp1.setLastName(lastName);
	 * emp1.setMailId(mailId); emp1.setHireDate(hireDate); emp1.setJobId(jobId);
	 * 
	 * return emp1; } }
	 */
}
	
