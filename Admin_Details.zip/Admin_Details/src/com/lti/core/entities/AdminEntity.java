package com.lti.core.entities;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Entity(name="Admin")
@Table(name="ADMIN")
public class AdminEntity {
	@Id
	@Column(name="USER_ID")
	 private int userId;
	@Column(name="FIRST_NAME")
	 private String firstName;
	@Column(name="LAST_NAME")
	 private String lastName;
	
	 
	public AdminEntity() {
		
	 System.out.println("Employee object created");	
	}

	public AdminEntity(int userId, String firstName, String lastName) {
		super();
		this.userId = userId;
		this.firstName = firstName;
		this.lastName = lastName;
	}

	public int getuserId() {
		return userId;
	}

	public void setuserId(int userId) {//empId
		this.userId = userId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {//firstName
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/*@Override
	public String toString() {
		return "Employee [empId=" + empId + ", firstName=" + firstName + ", lastName=" + lastName + ", mailId=" + mailId
				+ ", hireDate=" + hireDate + ", jobId=" + jobId + "]";
	}
*/
	

}